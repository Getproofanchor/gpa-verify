# GetProofAnchor — Independent Verification Guide

### For forensic experts and court-appointed technical examiners

---

## What this archive is

This archive (`GetProofAnchor_Evidence_<id>.zip`) is a tamper-evident
digital evidence package. The package is constructed so that any
subsequent modification — to any captured artifact or metadata — is
detectable mathematically.

There are two kinds of package. Check `proof.json` → `capture.mode` to
see which one you are holding.

### Web capture (`capture.mode` = `server` or `browser`)

Records what a specific URL **displayed** at a specific moment. Contains
`screenshot.png`, `page.html`, optionally `page.mhtml` and `capture.webm`,
and network evidence under `network/`.

### File digest certification (`capture.mode` = `file_digest`)

Records that a **specific file** with a specific SHA-256 digest was
available at a specific URL at a specific moment. Contains
`files_manifest.json` with the digest and the circumstances of
acquisition, and network evidence about the serving host.

There is no screenshot or page HTML — the subject of the evidence is a
file, not a rendered page. Verification steps 1 to 4 below apply
unchanged; step 5 applies only to the artifacts actually present.

**Whether the file itself is included depends on the order.** Check
`capture/capture_meta.json` → `retention`:

* `retained_in_package` — the file is in `files/`. Recompute its SHA-256
  and compare with `files_manifest.json`. This proves both the contents
  and the time of acquisition.
* `not_retained` — the file contents were deleted after the digest was
  computed and are **not** part of this package. The record proves that a
  file with the stated digest was available at the stated URL at the
  stated time; it does **not** prove what the file contained. To
  demonstrate contents, the holder must supply their own copy — anyone
  can then recompute its SHA-256 and match it against this record.

## What you, the verifier, are about to do

You will run a series of cryptographic checks that confirm four
independent properties of the archive:

* **Integrity** — no file inside the archive has been altered since
  it was sealed.
* **Time** — the archive was sealed by a qualified EU trust service
  provider at the recorded moment.
* **Provenance chain** — the archive is part of an append-only
  sequence anchored both to a qualified time-stamping authority
  (eIDAS, Article 42) and to the Bitcoin blockchain
  (OpenTimestamps).
* **Network attribution** — the TLS certificate, DNS records, and
  HAR transaction log captured during retrieval are internally
  consistent and link the captured content to the named domain.

If all four properties verify, the archive is cryptographically intact
and bears a genuine eIDAS-qualified timestamp. The chain of trust
flows through EU-listed authorities and the Bitcoin blockchain — the
verification can be reproduced without any ongoing dependency on the
GetProofAnchor service.

## What this verification does NOT prove

A complete and honest forensic conclusion requires that you understand
the limits of these checks. The verification does **not**, by itself,
prove:

* **That the on-screen content was an authentic representation of the
  named URL at capture time.** The verification proves the archive's
  internal cryptographic integrity and that the archive was sealed at
  the recorded time. It does not exclude the possibility that the
  capture process itself rendered something other than what a normal
  visitor would see. Mitigating evidence of a faithful capture lives
  in the bundle (HAR network log, TLS certificate evidence, recorded
  video, multi-resolver DNS) — interpreting that evidence is a
  forensic judgement, not a cryptographic certainty.
* **That the OpenTimestamps Bitcoin anchor has been confirmed in a
  block.** The receipt structure is verified offline; full Bitcoin
  block inclusion requires a Bitcoin node and is typically confirmed
  within a few hours after the seal. The `gpa-verify` CLI can perform
  this check against your own Bitcoin node with the `--bitcoin-rpc`
  option (see Path A).
* **That the eIDAS qualified trust service provider was listed on the
  EU Trusted List at the moment of sealing.** A snapshot of the
  relevant EU Trusted List(s) is included in the bundle, and the
  verifier checks the timestamp's signer certificate against it
  offline. This reflects the trust status recorded in that bundled
  snapshot; it is not a real-time query against the live EU Trusted
  List, and qualified status can in principle change over time.

These limitations are common to every forensic verification tool that
operates on data after the fact. They do not weaken the integrity
guarantees above; they state honestly what those guarantees mean.

---

## Two ways to verify

| Path | Speed | Effort | Audit value |
|------|-------|--------|-------------|
| **A — `gpa-verify` CLI** (recommended) | 2 seconds | one command | identical, fully reproducible |
| **B — manual step-by-step** (advanced) | 5 minutes | five commands | full transparency, every step visible |

Both paths verify exactly the same things. The CLI is the reference
implementation of the manual procedure — its source code is published
under MIT licence and can be audited line by line at
https://github.com/getproofanchor/gpa-verify.

> **Note on Python command name:** On Linux and macOS the command is
> `python3`. On Windows it is `python`. Examples in Path B use
> `python3`; substitute as appropriate for your platform.

---

# Path A — Verify with `gpa-verify` CLI

`gpa-verify` is a single open-source Python tool that runs all checks
offline and prints a verdict.

## Install

```bash
pip install gpa-verify
```

Requires Python 3.9 or newer. Two pure-Python wheels are installed
automatically: `asn1crypto` and `cryptography`. No system packages, no
compiled code, no GetProofAnchor servers contacted at any point during
verification.

## Run

```bash
gpa-verify GetProofAnchor_Evidence_*.zip
```

Expected output:

```
GetProofAnchor Evidence Verifier
────────────────────────────────────────────────────────────────
  Proof ID:       <uuid>
  Bundle format:  getproofanchor-evidence-4
  Generated at:   <UTC timestamp>

  [PASS]  bundle_integrity        — every file's SHA-256 matches manifest
  [PASS]  cross_references        — proof.json claims agree with files
  [PASS]  chain_integrity         — append-only event log is intact
  [PASS]  eidas_signature         — RFC 3161 token cryptographically valid
  [PASS]  tsl_qualified           — signer is a granted qualified TSA in the EU Trusted List
  [PASS]  anchor_canonical_hash   — anchor SHA matches manifest
  [PASS]  ots_receipt             — OpenTimestamps proof structurally OK
  [PASS]  tls_evidence            — TLS leaf cert matches network record

  ✓ VERIFIED  (8 passed, 0 failed, 0 skipped)
```

Exit code `0` means VERIFIED. Any non-zero exit code means at least
one layer failed; the offending layer's output explains exactly what.

The `cross_references` layer also re-hashes the offline `page.mhtml`
snapshot (when present) against both `proof.json` and the eIDAS-signed
payload, so a browser- or server-captured MHTML archive is confirmed to
be sealed under the qualified timestamp.

`tls_evidence` shows `SKIP` for browser-extension captures, which do
not include server TLS certificate material — that is expected, not a
failure.

For optional real Bitcoin block verification against your own node
(reads the receipt, never modifies it):

```bash
pip install "gpa-verify[bitcoin]"
gpa-verify --bitcoin-rpc "http://user:pass@127.0.0.1:8332" GetProofAnchor_Evidence_*.zip
```

For a machine-readable JSON report (suitable for inclusion as an
expert testimony exhibit):

```bash
gpa-verify --json GetProofAnchor_Evidence_*.zip > verification_report.json
```

The reference implementation, threat model documentation, and full
test suite are published at:
https://github.com/getproofanchor/gpa-verify

---

# Path B — Manual verification (advanced)

If you prefer to run each check by hand — for full transparency, or
because you cannot install Python packages on the verification machine —
follow steps 1–5 below. They reproduce exactly what `gpa-verify` does.

## Step 1 — Verify file integrity

This confirms that no file in the package has been added, removed, or
modified since the archive was sealed.

```bash
python3 - <<'EOF'
import json, hashlib
from pathlib import Path

manifest = json.load(open("manifest.json"))
errors = 0
for rel_path, meta in manifest["files"].items():
    path = Path(rel_path)
    if not path.exists():
        print(f"MISSING:  {rel_path}")
        errors += 1
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != meta["sha256"]:
        print(f"MODIFIED: {rel_path}")
        print(f"  expected: {meta['sha256']}")
        print(f"  actual:   {actual}")
        errors += 1

if errors == 0:
    print(f"PASS — all {len(manifest['files'])} files intact, no tampering detected")
else:
    print(f"FAIL — {errors} file(s) have been modified or are missing")
EOF
```

**Expected result:** `PASS — all N files intact, no tampering detected`

## Step 1b — Confirm the offline MHTML snapshot is sealed

If the bundle contains `page.mhtml` (a self-contained RFC 2557 archive
of the page with all CSS, images and fonts embedded inline), confirm
its SHA-256 matches both `proof.json` and the eIDAS-signed payload. The
second match is the important one: it proves the offline snapshot is
sealed under the qualified timestamp, not merely self-consistent.

```bash
python3 - <<'EOF'
import json, hashlib, os

if not os.path.exists("page.mhtml"):
    print("SKIP — no page.mhtml in this bundle")
else:
    actual = hashlib.sha256(open("page.mhtml","rb").read()).hexdigest()
    proof = json.load(open("proof.json"))
    payload = json.load(open("timestamp/eidas_payload.json"))
    ok = True
    if proof.get("mhtml_sha256") not in (None, actual):
        print("FAIL — page.mhtml does not match proof.json.mhtml_sha256"); ok = False
    if payload.get("mhtml_sha256") not in (None, actual):
        print("FAIL — page.mhtml does not match eIDAS-signed payload"); ok = False
    if ok:
        print("PASS — page.mhtml intact and sealed under the eIDAS timestamp")
        print("  sha256:", actual)
EOF
```

**Expected result:** `PASS — page.mhtml intact and sealed under the eIDAS timestamp`

You can open `page.mhtml` directly in any Chromium-based browser to see
the page rendered offline, exactly as captured — even if the original
site has since changed or disappeared. Note the documented limits of
MHTML: web-component/Shadow-DOM content and cross-origin iframes are not
serialized, and offline JavaScript does not execute. MHTML is a faithful
offline snapshot, not a live re-execution of the page.

## Step 2 — Verify the qualified timestamp (eIDAS)

This confirms that the archive existed in its current form at the
recorded time, and that the timestamp was issued by an EU-accredited
qualified trust service provider.

```bash
openssl ts -verify \
  -in timestamp/eidas.tsr \
  -data timestamp/eidas_payload.json \
  -CAfile timestamp/*.tsa_certs.pem
```

**Expected result:** `Verification: OK`

If openssl complains about `unable to get local issuer certificate`,
verify the cryptographic signature directly with Python. This script
also enforces the **timeStamping Extended Key Usage** on the signer
certificate, which is required by RFC 3161 for legitimate
time-stamping authority certificates:

```bash
pip install asn1crypto cryptography

python3 - <<'EOF'
from asn1crypto import tsp, cms
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
import hashlib

tsr_bytes = open("timestamp/eidas.tsr","rb").read()
data_bytes = open("timestamp/eidas_payload.json","rb").read()
data_hash = hashlib.sha256(data_bytes).digest()

resp = tsp.TimeStampResp.load(tsr_bytes)
ci = cms.ContentInfo.load(resp["time_stamp_token"].dump())
sd = ci["content"]
tst = tsp.TSTInfo.load(sd["encap_content_info"]["content"].parsed.dump())

# 1. Imprint must match the data we expect to be timestamped
imprint = tst["message_imprint"]["hashed_message"].native
assert imprint == data_hash, "FAIL — imprint does not match payload"
print("Imprint match: OK")

# 2. Signer cert must have timeStamping EKU (RFC 3161 § 2.3)
si = sd["signer_infos"][0]
cert_der = sd["certificates"][0].chosen.dump()
cert = x509.load_der_x509_certificate(cert_der)
eku = cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
assert x509.oid.ExtendedKeyUsageOID.TIME_STAMPING in eku, \
    "FAIL — signer cert lacks timeStamping EKU"
print("EKU timeStamping: OK")

# 3. CMS signature over signed_attrs (RFC 5652 — re-encode [0] to SET OF)
signed_attrs = si["signed_attrs"].dump()
if signed_attrs[0] == 0xA0:
    signed_attrs = b"\x31" + signed_attrs[1:]
cert.public_key().verify(
    si["signature"].native, signed_attrs, padding.PKCS1v15(), hashes.SHA512()
)
print("Signature: OK")
print("Timestamp:", tst["gen_time"].native.isoformat())
EOF
```

**Expected result:** all three lines `OK`, plus the timestamp.

> **Note:** the script above assumes RSA-PKCS1v15 with SHA-512, which
> matches the current GetProofAnchor TSA configuration. If you
> encounter a different TSA (RSA-PSS, ECDSA, or a different digest
> algorithm), use the `gpa-verify` CLI from Path A — it dispatches
> correctly across all three signature algorithm families.

To confirm the qualified status of the trust service provider,
inspect the metadata:

```bash
python3 -c "
import json
m = json.load(open('timestamp/eidas_meta.json'))
print('Provider:', m['tsa_name'])
print('URL:     ', m['tsa_url'])
print('Time:    ', m['ts_at'])
print('Status:  ', m['status'])
"
```

The provider must appear on the **EU Trusted List**
(https://ec.europa.eu/tools/lotl/eu-lotl.xml). The relevant
member-state Trusted List taken at capture time is included in this
bundle under `timestamp/tsl/` (for example `timestamp/tsl/EE.xml` for
an Estonian provider) for reproducible offline review. The
`gpa-verify` CLI uses it to confirm, offline, that the timestamp's
signer certificate is listed under a service of type
`TSA/QTST` (qualified time-stamp) with status `granted`.

## Step 3 — Verify the Bitcoin blockchain anchor

A second, independent timestamp anchored in the Bitcoin blockchain.
This is independent of any company, authority, or trust framework —
it depends only on the immutability of Bitcoin block headers.

```bash
pip install opentimestamps-client

python3 - <<'EOF'
import json, subprocess

p = json.load(open("proof.json"))
payload_sha = p["anchor"]["payload_sha256"]
print(f"Anchor hash:   {payload_sha}")
print(f"Bitcoin block: {p['ots']['bitcoin_block']}")
print(f"Bitcoin tx:    {p['ots']['bitcoin_tx']}")
print()

result = subprocess.run(
    ["ots", "verify", "anchor/anchor_receipt.ots", "-d", payload_sha],
    capture_output=True, text=True
)
print(result.stdout + result.stderr)
EOF
```

**Expected result:** output containing `Success` or
`attests existence as of <Bitcoin block>`.

A `pending` status means the anchor has been registered with
OpenTimestamps calendars but has not yet been included in a Bitcoin
block. Bitcoin confirmation typically completes within 2–6 hours
after the seal.

**Alternative — no installation:**

1. Upload `anchor/anchor_receipt.ots` at https://opentimestamps.org
2. When prompted for the data hash, enter the value of
   `proof.json → anchor → payload_sha256`

### Step 3b — Link this proof to the anchored chain head

The Bitcoin anchor attests to the chain head at one moment in time, and
that head is usually a *later* entry than the one recording this proof:
several proofs are typically sealed between two anchor runs. Check
`anchor/anchor_payload.json` → `covers_from_seq` and `covers_to_seq`
(payload `v` 2 and above); this proof's own sequence number, in
`chain/chain_head.json` → `seq`, must fall inside that range.

When this proof's entry **is** the anchored head, the two hashes match
directly and there is nothing further to do:

```bash
python3 - <<'EOF'
import json
head   = json.load(open("chain/chain_head.json"))
anchor = json.load(open("anchor/anchor_payload.json"))
print("proof head :", head["entry_hash"])
print("anchored   :", anchor["head"])
print("direct match:", head["entry_hash"] == anchor["head"])
EOF
```

Otherwise the bundle contains `chain/anchor_witness.jsonl`, which bridges
the gap. Each line is one chain entry between this proof and the anchored
head, reduced to `seq`, `prev_hash` and `entry_hash`. Because every entry
stores the previous entry's hash, walking that list from this proof's
entry must arrive exactly at the anchored head:

```bash
python3 - <<'EOF'
import json, os

head   = json.load(open("chain/chain_head.json"))
anchor = json.load(open("anchor/anchor_payload.json"))

if head["entry_hash"] == anchor["head"]:
    print("PASS — this proof's entry IS the anchored head")
    raise SystemExit

if not os.path.exists("chain/anchor_witness.jsonl"):
    print("FAIL — anchored head differs and no witness is present")
    raise SystemExit(1)

witness = [json.loads(l) for l in open("chain/anchor_witness.jsonl") if l.strip()]

expected_seq = head["seq"] + 1
cursor = head["entry_hash"]
for w in witness:
    if w["seq"] != expected_seq:
        print(f"FAIL — gap in witness before seq {w['seq']}")
        raise SystemExit(1)
    if w["prev_hash"] != cursor:
        print(f"FAIL — broken link at seq {w['seq']}")
        raise SystemExit(1)
    cursor = w["entry_hash"]
    expected_seq += 1

if cursor == anchor["head"]:
    print(f"PASS — chain of {len(witness)} entries links this proof "
          f"(seq {head['seq']}) to the anchored head (seq {anchor['seq']})")
else:
    print("FAIL — witness does not terminate at the anchored head")
    raise SystemExit(1)
EOF
```

**Expected result:** either `PASS — this proof's entry IS the anchored
head` or `PASS — chain of N entries links this proof …`.

**Why the witness carries only hashes.** The intervening entries record
*other customers'* evidence. Publishing their `proof_id` and `data_hash`
in this bundle would disclose unrelated parties' activity, so the witness
is reduced to the three fields linkage actually needs. This proves that
this proof's entry is an ancestor of the anchored head — and therefore
that it existed before the Bitcoin commitment — without revealing
anything about the proofs in between beyond how many there were. It does
not, and is not meant to, let you re-derive those entries' contents.

Note that a `pending` anchor still bounds this proof from *below* through
the qualified timestamp in Step 2; the blockchain anchor adds an
independent upper bound once it confirms.

## Step 4 — Verify the hash chain

This confirms the internal append-only event log has not been
modified.

```bash
python3 - <<'EOF'
import json, hashlib

entries = [json.loads(l) for l in open("chain/proof_chain.jsonl") if l.strip()]
head = json.load(open("chain/chain_head.json"))
errors = 0

for i, e in enumerate(entries):
    if i > 0 and e["prev_hash"] != entries[i-1]["entry_hash"]:
        print(f"FAIL — chain broken at seq {e['seq']}")
        errors += 1
    material = f"{e['prev_hash']}|{e['event_type']}|{e['proof_id']}|{e['data_hash']}".encode()
    computed = hashlib.sha256(material).hexdigest()
    if computed != e["entry_hash"]:
        print(f"FAIL — entry_hash mismatch at seq {e['seq']}")
        errors += 1

if head["entry_hash"] != entries[-1]["entry_hash"]:
    print("FAIL — chain head does not match last entry")
    errors += 1

if errors == 0:
    print(f"PASS — chain intact ({len(entries)} entries, all entry hashes verified)")
EOF
```

**Expected result:** `PASS — chain intact (N entries, all entry hashes verified)`

## Step 5 — Verify ISO/IEC 27037 forensic artifacts

Network-layer evidence required by ISO/IEC 27037 § 6.4–6.5: TLS
chain, DNS, HTTP archive, and the optional video recording.

### 5a — TLS / SSL certificate chain

```bash
openssl x509 -in tls/leaf_cert.pem -noout -subject -issuer -dates -fingerprint -sha256
openssl verify -CAfile /etc/ssl/certs/ca-certificates.crt tls/chain.pem
```

The leaf certificate's `subject` (or `subjectAltName`) must cover the
captured hostname. `verify OK` confirms the chain links to a public
certification authority.

Cross-check the SHA-256 fingerprint against `network/tls.json` →
`leaf_certificate.sha256_fingerprint`. They must match — this is
strong evidence that the certificate observed by the capture engine
is the same one preserved in the bundle.

### 5b — DNS resolution snapshot

Multi-resolver DNS evidence (Cloudflare 1.1.1.1, Google 8.8.8.8,
Quad9 9.9.9.9) captured at the same time as the page. Cross-resolver
agreement helps detect DNS hijacking at capture time.

```bash
python3 -c "
import json
d = json.load(open('network/dns.json'))
print('Hostname:    ', d['hostname'])
print('Captured at: ', d['captured_at_utc'])
for rtype, vals in d.get('records', {}).items():
    print(f'  {rtype:6s}', list(vals.values())[0].get('answers'))
"
```

### 5c — HTTP transaction log (HAR)

The HAR file (`network/capture.har`) is a standard W3C HTTP Archive
containing the full request/response sequence of the capture session.
It allows independent verification of the absence of unexpected
redirects, in-transit modification, or anomalous response status.

```bash
python3 -c "
import json
har = json.load(open('network/capture.har'))
entries = har.get('log',{}).get('entries',[])
print(f'{len(entries)} HTTP transactions during capture')
for e in entries[:5]:
    req = e['request']; resp = e['response']
    print(f'  {resp[\"status\"]:3d} {req[\"method\"]:4s} {req[\"url\"][:80]}')"
```

### 5d — Video recording

If `capture.webm` is present, it shows the actual capture session
exactly as the forensic browser rendered it. Open in any modern
video player (VLC, browser).

```bash
ffprobe -v error -show_format -show_streams capture.webm 2>&1 | head -10
```

### 5e — RDAP / WHOIS snapshot

`network/rdap.json` records the registrant, registrar, registration
date, and expiration as visible at capture time — useful when the
domain is later moved, seized, or re-registered.

```bash
python3 -c "
import json
d = json.load(open('network/rdap.json'))['data']
print('Domain:        ', d.get('ldhName'))
print('Status:        ', d.get('status'))
for ev in d.get('events', []):
    print(f'  {ev[\"eventAction\"]:20s} {ev[\"eventDate\"]}')"
```

---

## What the results mean

| Step | PASS means |
|------|------------|
| 1 — File integrity | Package has not been modified since generation |
| 1b — MHTML snapshot | Offline page archive is intact and sealed under the eIDAS timestamp |
| 2 — eIDAS timestamp | Evidence existed in this exact form at the stated time; signature verified by an EU-accredited authority |
| 3 — Bitcoin anchor | Evidence existed at or before Bitcoin block N; verifiable on the public blockchain |
| 4 — Hash chain | Internal append-only event log is intact |
| 5 — ISO 27037 artifacts | Network-layer evidence is internally consistent and links the captured content to the named domain |

**If all steps pass:** the package is cryptographically intact
and the eIDAS-bound timestamp is genuine. This conclusion is
independently reproducible by any expert with the tools above and
the artifacts inside this archive — the chain of trust flows through
eIDAS-listed authorities and the Bitcoin blockchain.

**For a complete forensic opinion**, this cryptographic verification
is necessary but not sufficient. The on-screen content of the
captured page is authoritative only insofar as the network evidence
(HAR transaction log, TLS certificate, multi-resolver DNS) is
consistent with normal serving by the named domain. Those artifacts
are included in the archive for that purpose; their interpretation
is a forensic judgement which a qualified examiner makes on the
totality of the evidence.

---

## References

* **eIDAS Regulation (EU) 910/2014**, Article 42 — qualified
  electronic timestamps enjoy a legal presumption of accuracy of the
  date and time and integrity of the data to which they are bound.
* **ETSI EN 319 422** — Time-stamping protocol and electronic
  time-stamp profiles.
* **ETSI EN 319 421** — Policy and security requirements for trust
  service providers issuing time-stamps.
* **ETSI EN 319 102-1** — Procedures for creation and validation of
  AdES digital signatures.
* **ISO/IEC 27037:2012** — Guidelines for identification, collection,
  acquisition and preservation of digital evidence.
* **RFC 3161** — Internet X.509 Public Key Infrastructure
  Time-Stamp Protocol (TSP).
* **RFC 5652** — Cryptographic Message Syntax (CMS).
* **OpenTimestamps protocol** — https://opentimestamps.org/
* **EU Trusted List** — https://ec.europa.eu/tools/lotl/eu-lotl.xml

---

*Generated by GetProofAnchor — https://getproofanchor.com*
*Verifier source code: https://github.com/getproofanchor/gpa-verify*