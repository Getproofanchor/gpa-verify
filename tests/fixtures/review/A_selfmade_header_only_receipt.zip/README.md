# GetProofAnchor — Independent Verification Guide

### For forensic experts and court-appointed technical examiners

This archive is a tamper-evident digital evidence package. Any later
modification — to any captured artifact or to the metadata — is
mathematically detectable.

Verification needs nothing from GetProofAnchor. Every artifact required is
inside the archive, and the chain of trust runs through an EU-listed
qualified trust service provider and the Bitcoin blockchain.

---

## Which package is this?

Two kinds exist and they prove different things. Run this first:

```bash
python3 -c "import json; print(json.load(open('proof.json'))['capture']['mode'])"
```

| Result | Package | Subject of the evidence |
|--------|---------|-------------------------|
| `server` or `browser` | **Web capture** | What a URL *displayed* at a moment in time |
| `file_digest` | **File digest certification** | That a *specific file* with a specific SHA-256 was obtained at a moment in time |

Section 2 describes each in detail. The verification in section 1 covers
both; the manual procedure in section 4 is split so you only run the steps
that apply to the package in front of you.

**Contents**

1. [Verify in one command](#1-verify-in-one-command)
2. [What this package contains](#2-what-this-package-contains)
3. [What a PASS proves — and what it does not](#3-what-a-pass-proves--and-what-it-does-not)
4. [Manual verification](#4-manual-verification)
5. [Interpreting the result](#5-interpreting-the-result)
6. [References](#6-references)

Sections 1 to 3 are enough for most examinations.

---

## 1. Verify in one command

`gpa-verify` is an open-source Python tool that runs every check in this
guide offline and prints a verdict. It is the reference implementation of
the manual procedure in section 4, so both routes verify the same things.
Its source is published under the MIT licence and can be audited line by
line at https://github.com/Getproofanchor/gpa-verify.

### Install

```bash
pip install gpa-verify
```

Requires Python 3.9 or newer. Two pure-Python wheels are installed
automatically: `asn1crypto` and `cryptography`. No system packages, no
compiled code, no GetProofAnchor servers contacted at any point during
verification.


```bash
gpa-verify GetProofAnchor_Evidence_*.zip
```

Expected output:

```
GetProofAnchor Evidence Verifier
────────────────────────────────────────────────────────────────
  Proof ID:       <uuid>
  Bundle format:  getproofanchor-evidence-4
  Generated at:   <UTC timestamp>

  [PASS]  bundle_integrity       — every file's SHA-256 matches the manifest
  [PASS]  cross_references       — proof.json claims agree with the files
  [PASS]  chain_integrity        — append-only event log is intact
  [PASS]  eidas_signature        — RFC 3161 token cryptographically valid
  [PASS]  tsl_qualified          — signer is a granted qualified TSA in the EU Trusted List
  [PASS]  anchor_canonical_hash  — anchor SHA matches the manifest
  [PASS]  ots_receipt            — OpenTimestamps proof structurally OK
  [PASS]  file_digest            — certified file digests agree with the sealed metadata
  [PASS]  anchor_witness         — (informational) chain witness is consistent
  [PASS]  tls_evidence           — TLS leaf cert matches the network record
  [PASS]  anchor_inclusion       — this proof's stamped payload is a leaf of the anchored Merkle tree

  ✓ VERIFIED  (11 passed, 0 failed, 0 skipped)
```

**`SKIP` is not a failure.** A layer is skipped when the artifact it
examines is not part of this kind of package — `file_digest` on a web
capture, `tls_evidence` on a browser-extension capture, or
`anchor_inclusion` on a package without `anchor/inclusion.json` (packages
generated before anchor v3, or proofs without a qualified timestamp).
`anchor_inclusion` needs gpa-verify 1.6.0 or later.

**Use version 1.5.0 or newer.** Earlier versions did not examine certified
file digests, so a file-digest package could report VERIFIED even if the
certified SHA-256 or the retained file contents had been altered. Check
with `gpa-verify --version`.

Exit code `0` means VERIFIED. Any non-zero exit code means at least
one layer failed; the offending layer's output explains exactly what.

The `cross_references` layer also re-hashes the offline `page.mhtml`
snapshot (when present) against both `proof.json` and the eIDAS-signed
payload, so a browser- or server-captured MHTML archive is confirmed to
be sealed under the qualified timestamp.

`tls_evidence` shows `SKIP` for browser-extension captures, which do
not include server TLS certificate material — that is expected, not a
failure.

For optional real Bitcoin block verification against your own node
(reads the receipt, never modifies it):

```bash
pip install "gpa-verify[bitcoin]"
gpa-verify --bitcoin-rpc "http://user:pass@127.0.0.1:8332" GetProofAnchor_Evidence_*.zip
```

For a machine-readable JSON report (suitable for inclusion as an
expert testimony exhibit):

```bash
gpa-verify --json GetProofAnchor_Evidence_*.zip > verification_report.json
```

The reference implementation, threat model documentation, and full
test suite are published at:
https://github.com/getproofanchor/gpa-verify


---

## 2. What this package contains

### Web capture (`capture.mode` = `server` or `browser`)

Records what a specific URL **displayed** at a specific moment. Contains
`screenshot.png`, `page.html`, optionally `page.mhtml` and `capture.webm`,
and network evidence under `network/`.

`screenshot.png` is a full-page render produced by the capture engine. It
may differ from what a visitor saw on screen: for example, fixed or sticky
overlays may have been hidden or de-duplicated while the page was stitched
into one image, and a consent dialog may have been clicked or hidden. The
interventions performed are recorded in `capture/capture_meta.json`
(`interaction_summary`). The authoritative record of the page is the set of
hashed artifacts: `page.html`, `page.mhtml`, the HAR and `capture.webm`,
where present.

When `capture.mode` is `browser` (`capture.source` =
`browser_extension`), the page was captured on the customer's device by
the GetProofAnchor browser extension. The page content, screenshot and
network data were supplied by the customer's browser; GetProofAnchor sealed
them on receipt. Integrity and time of receipt are proven, independent
observation of the content is not. The DNS, TLS and HTTP response values in
such a package are reported by the capturing browser.
### File digest certification (`capture.mode` = `file_digest`)

Records that a **specific file** with a specific SHA-256 digest was
available at a specific URL at a specific moment. Contains
`files_manifest.json` with the digest and the circumstances of
acquisition, and network evidence about the serving host.

There is no screenshot or page HTML — the subject of the evidence is a
file, not a rendered page. Verification steps 1 to 4 below apply
unchanged; step 5 applies only to the artifacts actually present.

**Whether the file itself is included depends on the order.** Check
`capture/capture_meta.json` → `retention`:

* `retained_in_package` — the file is in `files/`. Recompute its SHA-256
  and compare with `files_manifest.json`. This proves both the contents
  and the time of acquisition.
* `not_retained` — the file contents were deleted after the digest was
  computed and are **not** part of this package. The record proves that a
  file with the stated digest was available at the stated URL at the
  stated time; it does **not** prove what the file contained. To
  demonstrate contents, the holder must supply their own copy — anyone
  can then recompute its SHA-256 and match it against this record.

---

## 3. What a PASS proves — and what it does not

A full PASS confirms four independent properties:

| Property | What is established |
|----------|---------------------|
| **Integrity** | No file inside the archive has been altered since it was sealed |
| **Time** | A qualified EU trust service provider sealed the archive at the recorded moment |
| **Bitcoin anchor (anchor v3)** | Where `anchor/inclusion.json` is present: the exact payload signed by the qualified timestamp (and therefore every artifact digest it lists) is a leaf of a Merkle tree whose root is committed by an OpenTimestamps receipt. Without `anchor/inclusion.json` the Bitcoin anchor is an additional layer whose binding to this evidence cannot be shown from the package (see Step 3b) |
| **Network attribution** | For server captures and downloaded files: the TLS certificate, DNS records and transaction log captured during retrieval are internally consistent and link the content to the named domain. For browser-extension captures these values are reported by the capturing browser and are not an independent observation (see below) |

### What it does not prove

An honest forensic conclusion requires knowing the limits of these checks.
Verification does **not**, by itself, prove:


* **That the on-screen content was an authentic representation of the
  named URL at capture time.** The verification proves the archive's
  internal cryptographic integrity and that the archive was sealed at
  the recorded time. It does not exclude the possibility that the
  capture process itself rendered something other than what a normal
  visitor would see. The screenshot in particular is a full-page render
  in which overlays may have been hidden or de-duplicated; the
  interventions are listed in `capture/capture_meta.json`. Mitigating
  evidence of a faithful capture lives in the bundle (page HTML, MHTML,
  HAR network log, TLS certificate evidence, recorded video,
  multi-resolver DNS) — interpreting that evidence is a forensic
  judgement, not a cryptographic certainty.
* **That the OpenTimestamps Bitcoin anchor has been confirmed in a
  block.** The receipt structure is verified offline; full Bitcoin
  block inclusion requires a Bitcoin node and is typically confirmed
  within a few hours after the seal. The `gpa-verify` CLI can perform
  this check against your own Bitcoin node with the `--bitcoin-rpc`
  option (see section 1).
* **That a package without `anchor/inclusion.json` is covered by the
  Bitcoin anchor.** Older packages link to the anchor only through the
  chain witness (`chain/anchor_witness.jsonl`), which carries hashes that
  cannot be recomputed from the package. It is informational only. The
  qualified timestamp is the legal time evidence in every case.
* **That the Bitcoin anchor time is the capture time.** The anchor shows
  that the payload existed no later than the Bitcoin block; that block
  may be hours (or, for proofs anchored retroactively, months) after the
  capture.
* **That the eIDAS qualified trust service provider was listed on the
  EU Trusted List at the moment of sealing.** A snapshot of the
  relevant EU Trusted List(s) is included in the bundle, and the
  verifier checks the timestamp's signer certificate against it
  offline. This reflects the trust status recorded in that bundled
  snapshot; it is not a real-time query against the live EU Trusted
  List, and qualified status can in principle change over time.

These limitations are common to every forensic verification tool that
operates on data after the fact. They do not weaken the integrity
guarantees above; they state honestly what those guarantees mean.

* **That a file submitted by the customer came from anywhere in
  particular.** When `files_manifest.json` records a source beginning
  `upload:`, GetProofAnchor did not retrieve the file: the customer
  supplied the bytes. Such a package attests that those exact bytes were in
  GetProofAnchor's possession at the sealed time, and nothing about their
  origin. There is correspondingly no server, TLS or DNS evidence.
* **That a browser-extension capture shows what the named site served.**
  When `proof.json` records `capture.mode` = `browser` (`capture.source`
  = `browser_extension`), GetProofAnchor did not retrieve or render the
  page: the customer's browser supplied the page content, screenshot,
  HAR, video and the DNS/TLS values. Such a package attests that those
  exact bytes were in GetProofAnchor's possession at the time of receipt
  and have not changed since. It does not independently prove that the
  content, or the network values reported by the capturing browser, are
  what the named site actually served.

These limitations are common to every forensic verification tool that
operates on data after the fact. They do not weaken the guarantees above;
they state honestly what those guarantees mean.

---

## 4. Manual verification

Run each check by hand — for full transparency, or because you cannot
install Python packages on the verification machine. These steps reproduce
what `gpa-verify` does.

| | Applies to |
|---|---|
| **4.1 — Steps 1 to 4** | Every package |
| **4.2 — Step 5** | File digest certification only |
| **4.3 — Step 6** | Web capture only |

> **Python command name:** on Linux and macOS the command is `python3`, on
> Windows it is `python`. Examples below use `python3`.

---

### 4.1 Every package

#### Step 1 — Verify file integrity

This confirms that no file in the package has been added, removed, or
modified since the archive was sealed.

```bash
python3 - <<'EOF'
import json, hashlib
from pathlib import Path

manifest = json.load(open("manifest.json"))
errors = 0
for rel_path, meta in manifest["files"].items():
    path = Path(rel_path)
    if not path.exists():
        print(f"MISSING:  {rel_path}")
        errors += 1
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != meta["sha256"]:
        print(f"MODIFIED: {rel_path}")
        print(f"  expected: {meta['sha256']}")
        print(f"  actual:   {actual}")
        errors += 1

if errors == 0:
    print(f"PASS — all {len(manifest['files'])} files intact, no tampering detected")
else:
    print(f"FAIL — {errors} file(s) have been modified or are missing")
EOF
```

**Expected result:** `PASS — all N files intact, no tampering detected`


#### Step 2 — Verify the qualified timestamp (eIDAS)

This confirms that the archive existed in its current form at the
recorded time, and that the timestamp was issued by an EU-accredited
qualified trust service provider.

```bash
openssl ts -verify \
  -in timestamp/eidas.tsr \
  -data timestamp/eidas_payload.json \
  -CAfile timestamp/*.tsa_certs.pem
```

**Expected result:** `Verification: OK`

If openssl complains about `unable to get local issuer certificate`,
verify the cryptographic signature directly with Python. This script
also enforces the **timeStamping Extended Key Usage** on the signer
certificate, which is required by RFC 3161 for legitimate
time-stamping authority certificates:

```bash
pip install asn1crypto cryptography

python3 - <<'EOF'
from asn1crypto import tsp, cms
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
import hashlib

tsr_bytes = open("timestamp/eidas.tsr","rb").read()
data_bytes = open("timestamp/eidas_payload.json","rb").read()
data_hash = hashlib.sha256(data_bytes).digest()

resp = tsp.TimeStampResp.load(tsr_bytes)
ci = cms.ContentInfo.load(resp["time_stamp_token"].dump())
sd = ci["content"]
tst = tsp.TSTInfo.load(sd["encap_content_info"]["content"].parsed.dump())

# 1. Imprint must match the data we expect to be timestamped
imprint = tst["message_imprint"]["hashed_message"].native
assert imprint == data_hash, "FAIL — imprint does not match payload"
print("Imprint match: OK")

# 2. Signer cert must have timeStamping EKU (RFC 3161 § 2.3)
si = sd["signer_infos"][0]
cert_der = sd["certificates"][0].chosen.dump()
cert = x509.load_der_x509_certificate(cert_der)
eku = cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
assert x509.oid.ExtendedKeyUsageOID.TIME_STAMPING in eku, \
    "FAIL — signer cert lacks timeStamping EKU"
print("EKU timeStamping: OK")

# 3. CMS signature over signed_attrs (RFC 5652 — re-encode [0] to SET OF)
signed_attrs = si["signed_attrs"].dump()
if signed_attrs[0] == 0xA0:
    signed_attrs = b"\x31" + signed_attrs[1:]
cert.public_key().verify(
    si["signature"].native, signed_attrs, padding.PKCS1v15(), hashes.SHA512()
)
print("Signature: OK")
print("Timestamp:", tst["gen_time"].native.isoformat())
EOF
```

**Expected result:** all three lines `OK`, plus the timestamp.

> **Note:** the script above assumes RSA-PKCS1v15 with SHA-512, which
> matches the current GetProofAnchor TSA configuration. If you
> encounter a different TSA (RSA-PSS, ECDSA, or a different digest
> algorithm), use the `gpa-verify` CLI from section 1 — it dispatches
> correctly across all three signature algorithm families.

To confirm the qualified status of the trust service provider,
inspect the metadata:

```bash
python3 -c "
import json
m = json.load(open('timestamp/eidas_meta.json'))
print('Provider:', m['tsa_name'])
print('URL:     ', m['tsa_url'])
print('Time:    ', m['ts_at'])
print('Status:  ', m['status'])
"
```

The provider must appear on the **EU Trusted List**
(https://ec.europa.eu/tools/lotl/eu-lotl.xml). The relevant
member-state Trusted List taken at capture time is included in this
bundle under `timestamp/tsl/` (for example `timestamp/tsl/EE.xml` for
an Estonian provider) for reproducible offline review. The
`gpa-verify` CLI uses it to confirm, offline, that the timestamp's
signer certificate is listed under a service of type
`TSA/QTST` (qualified time-stamp) with status `granted`.


#### Step 3 — Verify the Bitcoin blockchain anchor

A second, independent timestamp anchored in the Bitcoin blockchain.
This is independent of any company, authority, or trust framework —
it depends only on the immutability of Bitcoin block headers.

```bash
pip install opentimestamps-client

python3 - <<'EOF'
import json, subprocess

p = json.load(open("proof.json"))
payload_sha = p["anchor"]["payload_sha256"]
print(f"Anchor hash:   {payload_sha}")
print(f"Bitcoin block: {p['ots']['bitcoin_block']}")
print(f"Bitcoin tx:    {p['ots']['bitcoin_tx']}")
print()

result = subprocess.run(
    ["ots", "verify", "anchor/anchor_receipt.ots", "-d", payload_sha],
    capture_output=True, text=True
)
print(result.stdout + result.stderr)
EOF
```

**Expected result:** output containing `Success` or
`attests existence as of <Bitcoin block>`.

A `pending` status means the anchor has been registered with
OpenTimestamps calendars but has not yet been included in a Bitcoin
block. Bitcoin confirmation typically completes within 2–6 hours
after the seal.

**Alternative — no installation:**

1. Upload `anchor/anchor_receipt.ots` at https://opentimestamps.org
2. When prompted for the data hash, enter the value of
   `proof.json → anchor → payload_sha256`

`ots verify` needs access to a Bitcoin node (a pruned node is enough;
`--bitcoin-node URL`). GetProofAnchor's own status "confirmed" in
`proof.json → ots → status` means that an OpenTimestamps calendar
supplied a Bitcoin attestation (`ots → status_label`: "attested");
it is "verified" only when `ots → verification` is
`verified_bitcoin_node`.


##### Step 3a — Verify that the anchor binds THIS evidence (anchor v3)

Packages generated since 2026-10-21 contain `anchor/inclusion.json` for
every proof with a qualified timestamp. It proves that this proof's
stamped payload is one leaf of the Merkle tree committed by the anchor:

* **Leaf** = SHA-256( `"gpa-anchor-leaf-v3"` ‖ 0x00 ‖ proof_id (UTF-8) ‖
  0x00 ‖ SHA-256(`timestamp/eidas_payload.json`) as 32 raw bytes ).
* **Tree** = RFC 6962 Merkle tree: leaf node = SHA-256(0x00 ‖ leaf),
  inner node = SHA-256(0x01 ‖ left ‖ right).
* **audit_path** is ordered from the leaf to the root; `side` is the side
  on which the sibling hash sits.
* **anchor_payload** (`v` 3) contains `merkle_root`, `leaf_count` and
  `leaf_algo`; SHA-256 of its canonical JSON (sorted keys, no spaces,
  UTF-8) is the digest committed by the `.ots` receipt named in
  `anchor_receipt_file` (`anchor/anchor_receipt.ots`, or
  `anchor/inclusion_anchor_receipt.ots` when the proof sits in a later
  anchor than the chain anchor).

```bash
python3 - <<'EOF'
import hashlib, json
H = lambda b: hashlib.sha256(b).digest()
inc = json.load(open("anchor/inclusion.json"))
payload_sha = hashlib.sha256(open("timestamp/eidas_payload.json", "rb").read()).hexdigest()
leaf = H(b"gpa-anchor-leaf-v3\x00" + inc["proof_id"].encode() + b"\x00" + bytes.fromhex(payload_sha))
assert leaf.hex() == inc["leaf_hash"], "leaf mismatch"
node = H(b"\x00" + leaf)
for step in inc["audit_path"]:
    sib = bytes.fromhex(step["hash"])
    node = H(b"\x01" + sib + node) if step["side"] == "L" else H(b"\x01" + node + sib)
assert node.hex() == inc["merkle_root"] == inc["anchor_payload"]["merkle_root"], "root mismatch"
ap = json.dumps(inc["anchor_payload"], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
assert hashlib.sha256(ap).hexdigest() == inc["anchor_payload_sha256"], "anchor payload mismatch"
assert open(inc["anchor_payload_file"], "rb").read() == ap, "anchor payload file mismatch"
ots = open(inc["anchor_receipt_file"], "rb").read()
magic = b"\x00OpenTimestamps\x00\x00Proof\x00\xbf\x89\xe2\xe8\x84\xe8\x92\x94"
assert ots.startswith(magic) and ots[len(magic)] == 1 and ots[len(magic) + 1] == 0x08
assert ots[len(magic) + 2:len(magic) + 34].hex() == inc["anchor_payload_sha256"], "receipt mismatch"
print("PASS — stamped payload is leaf", inc["leaf_index"], "of", inc["leaf_count"],
      "in the anchored tree; now run: ots verify -f", inc["anchor_payload_file"], inc["anchor_receipt_file"])
EOF
```

This short script walks the path by its `side` labels; the reference
verifier (`tools/verify_anchor_inclusion.py` in the GetProofAnchor
repository, and `gpa-verify` ≥ 1.6.0) additionally checks that the path
is consistent with `leaf_index` and `leaf_count` (RFC 9162 §2.1.3.2).
Finally run `ots verify` on the receipt with a Bitcoin node (Step 3).
Together with Step 2 (the timestamp binds every artifact digest listed
in `timestamp/eidas_payload.json`) this shows that the Bitcoin anchor
covers this evidence's content.


##### Step 3b — Chain witness (informational; packages without `anchor/inclusion.json`)

> **Informational only — not independently recomputable.** The witness
> lists `(seq, prev_hash, entry_hash)` only. Entry hashes depend on chain
> data that is not in the package, so a consistent-looking witness can be
> fabricated; it is **not** proof that the Bitcoin anchor covers this
> evidence. Use Step 3a where `anchor/inclusion.json` is present. For
> older packages the qualified timestamp (Step 2) is the time evidence.

The Bitcoin anchor attests to the chain head at one moment in time, and
that head is usually a *later* entry than the one recording this proof:
several proofs are typically sealed between two anchor runs. Check
`anchor/anchor_payload.json` → `covers_from_seq` and `covers_to_seq`
(payload `v` 2 and above); this proof's own sequence number, in
`chain/chain_head.json` → `seq`, must fall inside that range.

When this proof's entry **is** the anchored head, the two hashes match
directly and there is nothing further to do:

```bash
python3 - <<'EOF'
import json
head   = json.load(open("chain/chain_head.json"))
anchor = json.load(open("anchor/anchor_payload.json"))
print("proof head :", head["entry_hash"])
print("anchored   :", anchor["head"])
print("direct match:", head["entry_hash"] == anchor["head"])
EOF
```

Otherwise the bundle contains `chain/anchor_witness.jsonl`, which bridges
the gap. Each line is one chain entry between this proof and the anchored
head, reduced to `seq`, `prev_hash` and `entry_hash`. Because every entry
stores the previous entry's hash, walking that list from this proof's
entry must arrive exactly at the anchored head:

```bash
python3 - <<'EOF'
import json, os

head   = json.load(open("chain/chain_head.json"))
anchor = json.load(open("anchor/anchor_payload.json"))

if head["entry_hash"] == anchor["head"]:
    print("PASS — this proof's entry IS the anchored head")
    raise SystemExit

if not os.path.exists("chain/anchor_witness.jsonl"):
    print("FAIL — anchored head differs and no witness is present")
    raise SystemExit(1)

witness = [json.loads(l) for l in open("chain/anchor_witness.jsonl") if l.strip()]

expected_seq = head["seq"] + 1
cursor = head["entry_hash"]
for w in witness:
    if w["seq"] != expected_seq:
        print(f"FAIL — gap in witness before seq {w['seq']}")
        raise SystemExit(1)
    if w["prev_hash"] != cursor:
        print(f"FAIL — broken link at seq {w['seq']}")
        raise SystemExit(1)
    cursor = w["entry_hash"]
    expected_seq += 1

if witness and witness[-1]["seq"] != anchor["seq"]:
    print("FAIL — last witness seq differs from the anchored seq")
    raise SystemExit(1)
if cursor == anchor["head"]:
    print(f"PASS (informational) — chain of {len(witness)} entries links this proof "
          f"(seq {head['seq']}) to the anchored head (seq {anchor['seq']})")
else:
    print("FAIL — witness does not terminate at the anchored head")
    raise SystemExit(1)
EOF
```

**Expected result:** either `PASS — this proof's entry IS the anchored
head` or `PASS (informational) — chain of N entries links this proof …`.

**Why the witness carries only hashes.** The intervening entries record
*other customers'* evidence. Publishing their `proof_id` and `data_hash`
in this bundle would disclose unrelated parties' activity, so the witness
is reduced to three fields. Because those fields cannot be recomputed
from the package, the witness shows consistency, not ancestry; anchor v3
(Step 3a) replaces it with a recomputable Merkle inclusion proof that
reveals only sibling hashes.

Note that a `pending` anchor still bounds this proof from *below* through
the qualified timestamp in Step 2; the blockchain anchor adds an
independent upper bound once it confirms.


#### Step 4 — Verify the hash chain

This confirms the internal append-only event log has not been
modified.

```bash
python3 - <<'EOF'
import json, hashlib

entries = [json.loads(l) for l in open("chain/proof_chain.jsonl") if l.strip()]
head = json.load(open("chain/chain_head.json"))
errors = 0

for i, e in enumerate(entries):
    if i > 0 and e["prev_hash"] != entries[i-1]["entry_hash"]:
        print(f"FAIL — chain broken at seq {e['seq']}")
        errors += 1
    material = f"{e['prev_hash']}|{e['event_type']}|{e['proof_id']}|{e['data_hash']}".encode()
    computed = hashlib.sha256(material).hexdigest()
    if computed != e["entry_hash"]:
        print(f"FAIL — entry_hash mismatch at seq {e['seq']}")
        errors += 1

if head["entry_hash"] != entries[-1]["entry_hash"]:
    print("FAIL — chain head does not match last entry")
    errors += 1

if errors == 0:
    print(f"PASS — chain intact ({len(entries)} entries, all entry hashes verified)")
EOF
```

**Expected result:** `PASS — chain intact (N entries, all entry hashes verified)`


---

### 4.2 File digest certification only

#### Step 5 — Verify the certified file

**This is the step that matters most for this kind of package, and the one
an incomplete verification is most likely to omit.** Steps 1 to 4 prove the
archive is intact, correctly timestamped and correctly chained — none of
them look at the certified digest itself.

The check must be anchored on `capture/capture_meta.json` and `content.txt`,
because those are bound into the eIDAS payload and cannot be edited without
breaking the TSA signature. `manifest.json` is *not* sufficient on its own:
it is an index generated when the archive is assembled, after the timestamp
is issued, so anyone altering a digest could recompute it freely.

```bash
python3 - <<'EOF'
import json, hashlib, os, glob

fm      = json.load(open('files_manifest.json'))
sealed  = {f['filename']: f for f in
           json.load(open('capture/capture_meta.json')).get('files', [])}
content = open('content.txt', encoding='utf-8').read()
ok = True

for f in fm['files']:
    name, digest = f['filename'], f['sha256']
    print('\n' + name)
    print('  certified SHA-256 :', digest)

    s = sealed.get(name)
    if s is None:
        print('  FAIL - absent from eIDAS-sealed capture_meta.json'); ok = False
    elif s.get('sha256') != digest:
        print('  FAIL - sealed capture_meta.json says', s.get('sha256')); ok = False
    else:
        print('  matches eIDAS-sealed capture_meta.json : OK')

    if digest in content:
        print('  appears in eIDAS-sealed content.txt    : OK')
    else:
        print('  FAIL - digest absent from content.txt'); ok = False

    if f.get('retained_in_package'):
        stored = [p for p in glob.glob('files/*')
                  if os.path.basename(p).endswith(name)]
        if not stored:
            print('  FAIL - marked retained but no file under files/'); ok = False
        else:
            actual = hashlib.sha256(open(stored[0], 'rb').read()).hexdigest()
            print('  recomputed from files/ :', actual)
            if actual == digest:
                print('  preserved contents match               : OK')
            else:
                print('  FAIL - preserved contents do not match'); ok = False
    else:
        print('  contents not retained - see below')

print('\nPASS' if ok else '\nFAIL')
EOF
```

**Expected result:** `PASS`, with every listed check reporting `OK`.

**If the contents were not retained** (`capture_meta.json` → `retention` is
`not_retained`), the package proves that a file with the stated digest was
obtained at the stated time — not what the file contained. To establish
contents, take the holder's own copy and compare:

```bash
sha256sum their_copy_of_the_file
```

A match against the certified digest above ties that specific copy to the
timestamped record. A mismatch means the copy is not the file that was
certified.

---

### 4.3 Web capture only

Skip this section entirely for file-digest packages: a downloaded or
submitted file has no rendered page, so there is no screenshot, page HTML,
MHTML snapshot or video to examine.

#### Step 6a — Confirm the offline MHTML snapshot is sealed

If the bundle contains `page.mhtml` (a self-contained RFC 2557 archive
of the page with all CSS, images and fonts embedded inline), confirm
its SHA-256 matches both `proof.json` and the eIDAS-signed payload. The
second match is the important one: it proves the offline snapshot is
sealed under the qualified timestamp, not merely self-consistent.

```bash
python3 - <<'EOF'
import json, hashlib, os

if not os.path.exists("page.mhtml"):
    print("SKIP — no page.mhtml in this bundle")
else:
    actual = hashlib.sha256(open("page.mhtml","rb").read()).hexdigest()
    proof = json.load(open("proof.json"))
    payload = json.load(open("timestamp/eidas_payload.json"))
    ok = True
    if proof.get("mhtml_sha256") not in (None, actual):
        print("FAIL — page.mhtml does not match proof.json.mhtml_sha256"); ok = False
    if payload.get("mhtml_sha256") not in (None, actual):
        print("FAIL — page.mhtml does not match eIDAS-signed payload"); ok = False
    if ok:
        print("PASS — page.mhtml intact and sealed under the eIDAS timestamp")
        print("  sha256:", actual)
EOF
```

**Expected result:** `PASS — page.mhtml intact and sealed under the eIDAS timestamp`

You can open `page.mhtml` directly in any Chromium-based browser to see
the page rendered offline from the captured snapshot — even if the original
site has since changed or disappeared. Note the documented limits of
MHTML: web-component/Shadow-DOM content and cross-origin iframes are not
serialized, and offline JavaScript does not execute. MHTML is a faithful
offline snapshot, not a live re-execution of the page.


Network-layer evidence follows (collected with reference to ISO/IEC 27037
§ 6.4–6.5; this is not a certification of compliance). Run only the checks
whose artifacts are present. For browser-extension captures these values
are reported by the capturing browser, not observed by GetProofAnchor.

#### Step 6b — TLS / SSL certificate chain

```bash
# Certificate the server presented, and the hostnames it covers
openssl x509 -in tls/leaf_cert.pem -noout -subject -issuer -dates -fingerprint -sha256
openssl x509 -in tls/leaf_cert.pem -noout -ext subjectAltName

# Chain validation: leaf, with the bundled intermediates, up to a root your
# own machine already trusts
openssl verify -untrusted tls/chain.pem tls/leaf_cert.pem
```

**Expected result:** `tls/leaf_cert.pem: OK`

The leaf certificate's `subject` or `subjectAltName` must cover the captured
hostname. Shared-hosting certificates commonly carry a different common name
with the captured host appearing among the alternative names — that is normal
and not a defect.

Note that `tls/chain.pem` is a bundle of several certificates, so it is passed
as `-untrusted` (intermediates to build the path with) rather than as the file
being verified. The trust anchor is your own system store, not anything
supplied in this archive; validating the bundle against itself would be
circular and would prove nothing.

Cross-check the SHA-256 fingerprint against `network/tls.json` →
`leaf_certificate.sha256_fingerprint`. They must match — this is
strong evidence that the certificate observed by the capture engine
is the same one preserved in the bundle.


#### Step 6c — DNS resolution snapshot

Multi-resolver DNS evidence (Cloudflare 1.1.1.1, Google 8.8.8.8,
Quad9 9.9.9.9) captured at the same time as the page. Cross-resolver
agreement helps detect DNS hijacking at capture time.

```bash
python3 -c "
import json
d = json.load(open('network/dns.json'))
print('Hostname:    ', d['hostname'])
print('Captured at: ', d['captured_at_utc'])
for rtype, vals in d.get('records', {}).items():
    print(f'  {rtype:6s}', list(vals.values())[0].get('answers'))
"
```


#### Step 6d — HTTP transaction log (HAR)

The HAR file (`network/capture.har`) is a standard W3C HTTP Archive
containing the full request/response sequence of the capture session.
It allows independent verification of the absence of unexpected
redirects, in-transit modification, or anomalous response status.

```bash
python3 -c "
import json
har = json.load(open('network/capture.har'))
entries = har.get('log',{}).get('entries',[])
print(f'{len(entries)} HTTP transactions during capture')
for e in entries[:5]:
    req = e['request']; resp = e['response']
    print(f'  {resp[\"status\"]:3d} {req[\"method\"]:4s} {req[\"url\"][:80]}')"
```


#### Step 6e — Video recording

If `capture.webm` is present, it shows the capture session as recorded
by the capture engine (for browser-extension captures: as recorded by the
extension on the customer's device). Open in any modern
video player (VLC, browser).

```bash
ffprobe -v error -show_format -show_streams capture.webm 2>&1 | head -10
```


#### Step 6f — RDAP / WHOIS snapshot

`network/rdap.json` records the registrant, registrar, registration
date, and expiration as visible at capture time — useful when the
domain is later moved, seized, or re-registered.

```bash
python3 -c "
import json
d = json.load(open('network/rdap.json'))['data']
print('Domain:        ', d.get('ldhName'))
print('Status:        ', d.get('status'))
for ev in d.get('events', []):
    print(f'  {ev[\"eventAction\"]:20s} {ev[\"eventDate\"]}')"
```


---

## 5. Interpreting the result

| Step | Applies to | PASS means |
|------|-----------|------------|
| 1 — File integrity | all | The package has not been modified since it was generated |
| 2 — eIDAS timestamp | all | The evidence existed in this exact form at the stated time; the signature is verified against an EU-listed qualified authority |
| 3 — Bitcoin anchor | all | The anchor payload existed at or before the Bitcoin block (after `ots verify` with a Bitcoin node) |
| 3a — Anchor inclusion | packages with `anchor/inclusion.json` | This proof's timestamped payload — and so every artifact digest it lists — is committed by that anchor |
| 3b — Anchor witness | older packages | Informational only: the witness is self-consistent; it does not prove that the anchor covers this evidence |
| 4 — Hash chain | all | The internal append-only event log is intact |
| 5 — Certified file | file digest | The certified digest agrees with the eIDAS-sealed metadata; where contents were retained, they hash to that digest |
| 6a — MHTML snapshot | web capture | The offline page archive is intact and sealed under the eIDAS timestamp |
| 6b–6f — Network-layer artifacts | web capture | Network-layer evidence is internally consistent and links the captured content to the named domain (server captures; for browser-extension captures the values are reported by the capturing browser) |

**If all steps pass:** the package is cryptographically intact
and the eIDAS-bound timestamp is genuine. This conclusion is
independently reproducible by any expert with the tools above and
the artifacts inside this archive — the chain of trust flows through
eIDAS-listed authorities and, where `anchor/inclusion.json` is present,
the Bitcoin blockchain.

**For a complete forensic opinion**, this cryptographic verification is
necessary but not sufficient, and what remains open differs by package.

For a **web capture**, the on-screen content is authoritative only insofar as
the network evidence (HAR transaction log, TLS certificate, multi-resolver
DNS) is consistent with normal serving by the named domain.

For a **file digest certification** where contents were not retained, the
record fixes a digest and a time; what the file contained is established only
by matching a copy against that digest. Where the file was submitted by the
customer rather than downloaded, its origin is not established at all.

Those artifacts are included in the archive for that purpose; their
interpretation is a forensic judgement which a qualified examiner makes on the
totality of the evidence.


---

## 6. References

* **eIDAS Regulation (EU) 910/2014**, Article 42 — qualified
  electronic timestamps enjoy a legal presumption of accuracy of the
  date and time and integrity of the data to which they are bound.
* **ETSI EN 319 422** — Time-stamping protocol and electronic
  time-stamp profiles.
* **ETSI EN 319 421** — Policy and security requirements for trust
  service providers issuing time-stamps.
* **ETSI EN 319 102-1** — Procedures for creation and validation of
  AdES digital signatures.
* **ISO/IEC 27037:2012** — Guidelines for identification, collection,
  acquisition and preservation of digital evidence.
* **RFC 3161** — Internet X.509 Public Key Infrastructure
  Time-Stamp Protocol (TSP).
* **RFC 5652** — Cryptographic Message Syntax (CMS).
* **OpenTimestamps protocol** — https://opentimestamps.org/
* **EU Trusted List** — https://ec.europa.eu/tools/lotl/eu-lotl.xml

---

---

*Generated by GetProofAnchor — https://getproofanchor.com*
