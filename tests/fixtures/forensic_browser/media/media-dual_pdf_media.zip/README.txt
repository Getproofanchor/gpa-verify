GetProofAnchor Forensic Browser — companion media archive

Session: sess-539000778629
Sealed document: GetProofAnchor_sess-539000778629.pdf

The media files in this archive were too large to be embedded in the sealed PDF.
This archive itself carries no seal. Each file's SHA-256 is printed in the sealed PDF
and recorded in its embedded manifest.json (external_files), proof.json and
media/NN/media.json, which are covered by the document's qualified timestamp.
Verify: compute SHA-256 of a file below and compare it with the sealed value,
or run: gpa-verify <document.pdf> --media <this archive> (gpa-verify 1.7.2+).

e94c8c97bb6f6d4a04af774867b7d1e6401789319e86361cc38a1b593bb47b8c  media/01/video.mp4  (189402 B)
25cc59ff2fa2e72ce756a029c7ed979b4aead6509d40e85b5a3029b400017a2a  media/02/stream_400.ts  (169764 B)
d470619cad4484cc35b8e571eb2fc9546025eb4b17854748750cc91fe7bd15c1  media/02/stream_aud-cs.ts  (38164 B)
1e187051d4816072d07a9afbdacb555ad892690679e8a0011d6a3bfff0354d25  media/02/video.mp4  (190359 B)
