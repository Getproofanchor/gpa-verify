# GetProofAnchor — Independent Verification Guide
### For forensic experts and court-appointed technical examiners

---

This archive is a **tamper-evident digital evidence package**.
Your task: determine whether the package has been modified since it was generated.

All checks below use only standard open-source tools.
**No connection to GetProofAnchor is required.**

---

## Step 1 — Verify file integrity

This confirms that no file in the package has been added, removed, or modified.

```bash
python3 - <<'EOF'
import json, hashlib
from pathlib import Path

manifest = json.load(open("manifest.json"))
errors = 0
for rel_path, meta in manifest["files"].items():
    path = Path(rel_path)
    if not path.exists():
        print(f"MISSING:  {rel_path}")
        errors += 1
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != meta["sha256"]:
        print(f"MODIFIED: {rel_path}")
        print(f"  expected: {meta['sha256']}")
        print(f"  actual:   {actual}")
        errors += 1

if errors == 0:
    print(f"PASS — all {len(manifest['files'])} files intact, no tampering detected")
else:
    print(f"FAIL — {errors} file(s) have been modified or are missing")
EOF
```

**Expected result:** `PASS — all 23 files intact, no tampering detected`

Any `MODIFIED` or `MISSING` output indicates the package has been tampered with.

---

## Step 2 — Verify the qualified timestamp (eIDAS)

This confirms that the evidence data existed at the stated time, and that the timestamp was issued by an EU-accredited authority.

```bash
# Requires: openssl (standard on Linux/macOS; on Windows use Git Bash or WSL)

openssl ts -verify \
  -in timestamp/eidas.tsr \
  -data timestamp/eidas_payload.json \
  -CAfile timestamp/*.tsa_certs.pem
```

**Expected result:** `Verification: OK`

If you receive `unable to get local issuer certificate`, the bundle may not include the full CA chain.
In that case, use the alternative Python verification below, which validates the cryptographic signature directly:

```bash
python3 - <<'EOF'
from asn1crypto import tsp, cms
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.exceptions import InvalidSignature
import hashlib, json

tsr_bytes = open("timestamp/eidas.tsr","rb").read()
data_bytes = open("timestamp/eidas_payload.json","rb").read()
data_hash = hashlib.sha256(data_bytes).digest()

resp = tsp.TimeStampResp.load(tsr_bytes)
ci = cms.ContentInfo.load(resp["time_stamp_token"].dump())
sd = ci["content"]
tst = tsp.TSTInfo.load(sd["encap_content_info"]["content"].parsed.dump())
imprint = tst["message_imprint"]["hashed_message"].native
assert imprint == data_hash, "FAIL — imprint does not match payload"
print("Imprint match: OK")
si = sd["signer_infos"][0]
signed_attrs = si["signed_attrs"].dump()
if signed_attrs[0] == 0xA0: signed_attrs = b"\x31" + signed_attrs[1:]
cert_der = sd["certificates"][0].chosen.dump()
cert = x509.load_der_x509_certificate(cert_der)
cert.public_key().verify(si["signature"].native, signed_attrs, padding.PKCS1v15(), hashes.SHA256())
print("Signature: OK")
print("Timestamp:", tst["gen_time"].native.isoformat())
EOF
```

**Expected result:** `Imprint match: OK` and `Signature: OK`

Any other result means the timestamp signature is invalid.
> **Note:** The Python method validates the cryptographic signature without requiring the full CA chain.
> For complete chain validation, download the issuer cert from the URL in `Authority Information Access` of the signer certificate.

To confirm the timestamping authority is EU-accredited:

```bash
python3 -c "
import json
m = json.load(open('timestamp/eidas_meta.json'))
print('Provider:', m['tsa_name'])
print('URL:     ', m['tsa_url'])
print('Time:    ', m['ts_at'])
print('Status:  ', m['status'])
"
```

**Expected result:**
```
Provider: SK_ID_Solutions
URL:      https://tsa.sk.ee/rsa
Status:   ok
```

SK ID Solutions AS (Estonia) is listed on the EU Trusted List as a Qualified Trust Service Provider under eIDAS Regulation (EU) 910/2014.

EU Trusted List: https://ec.europa.eu/tools/lotl/eu-lotl.xml

---

## Step 3 — Verify the Bitcoin blockchain anchor

A second, independent timestamp anchored in the Bitcoin blockchain — independent of any company or authority.

```bash
# Requires: pip install opentimestamps-client

python3 - <<'EOF'
import json, subprocess

p = json.load(open("proof.json"))
payload_sha = p["anchor"]["payload_sha256"]
bitcoin_block = p["ots"]["bitcoin_block"]
bitcoin_tx = p["ots"]["bitcoin_tx"]

print(f"Anchor hash:   {payload_sha}")
print(f"Bitcoin block: {bitcoin_block}")
print(f"Bitcoin tx:    {bitcoin_tx}")
print()

result = subprocess.run(
    ["ots", "verify", "anchor/anchor_receipt.ots", "-d", payload_sha],
    capture_output=True, text=True
)
output = result.stdout + result.stderr
print(output)
if "Success" in output or "attests existence" in output:
    print("PASS — Bitcoin anchor verified")
else:
    print("FAIL or PENDING — see output above")
EOF
```

**Expected result:** Output containing `Success` or `attests existence as of` with the Bitcoin block number.

**Alternative — no installation required:**
1. Upload `anchor/anchor_receipt.ots` at **https://opentimestamps.org**
2. When prompted for the data hash, enter the value of `proof.json → anchor → payload_sha256`

> **Note:** `payload_sha256` is the SHA-256 of the canonical JSON of `anchor/anchor_payload.json` (sorted keys, no whitespace). It may differ from the raw file hash due to formatting.

**Alternative — verify on Bitcoin block explorer directly:**
- https://mempool.space/tx/`<proof.json → ots → bitcoin_tx>`
- https://blockstream.info/tx/`<proof.json → ots → bitcoin_tx>`

---

## Step 4 — Verify the hash chain

This confirms the internal event log has not been modified.

```bash
python3 - <<'EOF'
import json

entries = [json.loads(l) for l in open("chain/proof_chain.jsonl") if l.strip()]
head = json.load(open("chain/chain_head.json"))
errors = 0

for i, e in enumerate(entries):
    if i > 0 and e["prev_hash"] != entries[i-1]["entry_hash"]:
        print(f"FAIL — chain broken at seq {e['seq']}")
        errors += 1
    # Verify entry_hash = SHA256(prev_hash|event_type|proof_id|data_hash)
    import hashlib
    material = f"{e['prev_hash']}|{e['event_type']}|{e['proof_id']}|{e['data_hash']}".encode()
    computed = hashlib.sha256(material).hexdigest()
    if computed != e["entry_hash"]:
        print(f"FAIL — entry_hash mismatch at seq {e['seq']}")
        errors += 1

if head["entry_hash"] != entries[-1]["entry_hash"]:
    print("FAIL — chain head does not match last entry")
    errors += 1

if errors == 0:
    print(f"PASS — chain intact ({len(entries)} entries, all entry hashes verified)")
    for e in entries:
        print(f"  seq {e['seq']}: {e['event_type']} at {e['created_at']}")
EOF
```

**Expected result:** `PASS — chain intact (N entries, all entry hashes verified)`

---

## Step 5 — Verify ISO/IEC 27037 forensic artifacts

This is the network-layer evidence required by ISO/IEC 27037 § 6.4–6.5
and SWGDE 21-F-001 — DNS, TLS / SSL certificate, HTTP archive, and the
optional video recording of the capture session itself.

### 5a — TLS / SSL certificate chain

This proves the captured content was actually served by the claimed domain
(not a man-in-the-middle, not a hijacked DNS, not a clone server).

```bash
# Inspect the leaf cert that the target server presented during capture
openssl x509 -in tls/leaf_cert.pem -noout -subject -issuer -dates -fingerprint -sha256

# Verify the full chain links to a known root
openssl verify -CAfile /etc/ssl/certs/ca-certificates.crt tls/chain.pem
```

The leaf cert's `subject` should match the captured hostname (or be covered
by a SAN/wildcard SAN). The chain's `verify OK` confirms the certificate
was signed by a recognised public CA at capture time.

Cross-check the SHA-256 fingerprint against `network/tls.json` →
`leaf_certificate.sha256_fingerprint`. They must match.

### 5b — DNS resolution snapshot

Multi-resolver DNS evidence (Cloudflare 1.1.1.1, Google 8.8.8.8, Quad9 9.9.9.9)
captured at the same time as the page. `network/dns.json → consensus` shows
records all three resolvers agreed on; `divergence` lists record types where
they disagreed (forensic red flag).

```bash
python3 -c "
import json
d = json.load(open('network/dns.json'))
print('Hostname:    ', d['hostname'])
print('Captured at: ', d['captured_at_utc'])
for rtype, vals in d.get('consensus', {}).items():
    print(f'  {rtype:6s}', vals)
if d.get('divergence'):
    print('DIVERGENCE in:', d['divergence'])
"
```

### 5c — HTTP transaction log (HAR)

The HAR file (`network/capture.har`) is a standard W3C HTTP Archive containing
the full request/response sequence of the capture session. Useful to prove
the **absence** of unexpected redirects, JavaScript injection, or in-transit
modification.

```bash
# Open in any HAR viewer (Chrome DevTools, WebPageTest, etc.)
# Or count entries from CLI:
python3 -c "
import json
har = json.load(open('network/capture.har'))
entries = har.get('log',{}).get('entries',[])
print(f'{len(entries)} HTTP transactions during capture')
for e in entries[:5]:
    req = e['request']; resp = e['response']
    print(f'  {resp[\"status\"]:3d} {req[\"method\"]:4s} {req[\"url\"][:80]}')"
```

### 5d — Video recording (optional)

If `capture.webm` is present, it shows the actual capture session as
the forensic browser saw it. Open in any modern video player (VLC, browser).

```bash
ffprobe -v error -show_format -show_streams capture.webm 2>&1 | head -20
```

### 5e — RDAP / WHOIS snapshot

`network/rdap.json` carries the registrant, registrar, registration date,
and expiration as visible at capture time. Useful when the domain is later
moved, seized, or re-registered.

---

## What the results mean

| Check | PASS means |
|---|---|
| Step 1 — File integrity | Package has not been modified since it was generated |
| Step 2 — eIDAS timestamp | Evidence existed at the stated time; signature verified by EU-accredited authority |
| Step 3 — Bitcoin anchor | Evidence existed at or before Bitcoin block N; verifiable on the public blockchain |
| Step 4 — Hash chain | Internal event log is intact |
| Step 5 — ISO 27037 artifacts | Network-layer evidence (TLS, DNS, HAR) confirms the served-by-claimed-domain attribution |

**If all five steps pass: the package is cryptographically intact and forensically attested per ISO/IEC 27037.**

---

*Generated by GetProofAnchor — https://getproofanchor.com*
*eIDAS Regulation (EU) 910/2014, Article 41(2) · ISO/IEC 27037:2012 · SWGDE 21-F-001*

---
---

# GetProofAnchor — Průvodce nezávislým ověřením
### Pro soudní znalce a technické experty

---

Tento archiv je **digitální důkazní balíček chráněný proti manipulaci**.
Návod: Jak zjistit, zda byl balíček od vygenerování změněn.

Všechny níže uvedené kroky používají pouze standardní open-source nástroje.
**Připojení k systému GetProofAnchor není vyžadováno.**

---

## Krok 1 — Ověření integrity souborů

Potvrdí, že žádný soubor v balíčku nebyl přidán, odstraněn ani změněn.

```bash
python3 - <<'EOF'
import json, hashlib
from pathlib import Path

manifest = json.load(open("manifest.json"))
errors = 0
for rel_path, meta in manifest["files"].items():
    path = Path(rel_path)
    if not path.exists():
        print(f"CHYBÍ:   {rel_path}")
        errors += 1
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != meta["sha256"]:
        print(f"ZMENEN:  {rel_path}")
        print(f"  ocekavano: {meta['sha256']}")
        print(f"  skutecne:  {actual}")
        errors += 1

if errors == 0:
    print(f"PROSEL — vsech {len(manifest['files'])} souboru v poradku, manipulace nezjistena")
else:
    print(f"SELHAL — {errors} soubor(u) byl zmenen nebo chybi")
EOF
```

**Očekávaný výsledek:** `PROSEL — vsech 23 souboru v poradku, manipulace nezjistena`

Výstup `ZMENEN` nebo `CHYBI` znamená, že s balíčkem bylo manipulováno.

---

## Krok 2 — Ověření kvalifikovaného časového razítka (eIDAS)

Potvrdí, že důkazní data existovala v uvedený čas, a že razítko vydal EU-akreditovaný poskytovatel.

```bash
# Vyžaduje: openssl (standardně součást Linux/macOS; na Windows použijte Git Bash nebo WSL)

openssl ts -verify \
  -in timestamp/eidas.tsr \
  -data timestamp/eidas_payload.json \
  -CAfile timestamp/*.tsa_certs.pem
```

**Očekávaný výsledek:** `Verification: OK`

Pokud dostanete chybu `unable to get local issuer certificate`, bundle neobsahuje plný CA řetězec.
V takovém případě použijte alternativní Python ověření níže, které validuje kryptografický podpis přímo:

```bash
pip install asn1crypto cryptography
python3 - <<'EOF'
from asn1crypto import tsp, cms
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
import hashlib

tsr_bytes = open("timestamp/eidas.tsr","rb").read()
data_bytes = open("timestamp/eidas_payload.json","rb").read()
data_hash = hashlib.sha256(data_bytes).digest()

resp = tsp.TimeStampResp.load(tsr_bytes)
ci = cms.ContentInfo.load(resp["time_stamp_token"].dump())
sd = ci["content"]
tst = tsp.TSTInfo.load(sd["encap_content_info"]["content"].parsed.dump())
imprint = tst["message_imprint"]["hashed_message"].native
assert imprint == data_hash, "SELHAL — otisk neodpovida payloadu"
print("Otisk: OK")
si = sd["signer_infos"][0]
signed_attrs = si["signed_attrs"].dump()
if signed_attrs[0] == 0xA0: signed_attrs = b"\x31" + signed_attrs[1:]
cert_der = sd["certificates"][0].chosen.dump()
cert = x509.load_der_x509_certificate(cert_der)
cert.public_key().verify(si["signature"].native, signed_attrs, padding.PKCS1v15(), hashes.SHA256())
print("Podpis: OK")
print("Cas razitka:", tst["gen_time"].native.isoformat())
EOF
```

**Očekávaný výsledek:** `Otisk: OK` a `Podpis: OK`

Jakýkoliv jiný výsledek znamená, že podpis časového razítka není platný.

Pro potvrzení, že vydavatel razítka je EU-akreditovaný:

```bash
python3 -c "
import json
m = json.load(open('timestamp/eidas_meta.json'))
print('Poskytovatel:', m['tsa_name'])
print('URL:         ', m['tsa_url'])
print('Cas razitka: ', m['ts_at'])
print('Status:      ', m['status'])
"
```

**Očekávaný výsledek:**
```
Poskytovatel: SK_ID_Solutions
URL:          https://tsa.sk.ee/rsa
Status:       ok
```

SK ID Solutions AS (Estonsko) je zapsán na EU Trusted List jako Qualified Trust Service Provider dle nařízení eIDAS (EU) 910/2014.

EU Trusted List: https://ec.europa.eu/tools/lotl/eu-lotl.xml

---

## Krok 3 — Ověření Bitcoin blockchain anchoru

Druhé, nezávislé časové ukotvení v Bitcoin blockchainu — nezávislé na jakékoli společnosti nebo autoritě.

```bash
# Vyžaduje: pip install opentimestamps-client

python3 - <<'EOF'
import json, subprocess

p = json.load(open("proof.json"))
payload_sha = p["anchor"]["payload_sha256"]
bitcoin_block = p["ots"]["bitcoin_block"]
bitcoin_tx = p["ots"]["bitcoin_tx"]

print(f"Ukotvenych hash:  {payload_sha}")
print(f"Bitcoin blok:     {bitcoin_block}")
print(f"Bitcoin tx:       {bitcoin_tx}")
print()

result = subprocess.run(
    ["ots", "verify", "anchor/anchor_receipt.ots", "-d", payload_sha],
    capture_output=True, text=True
)
output = result.stdout + result.stderr
print(output)
if "Success" in output or "attests existence" in output:
    print("PROSEL — Bitcoin anchor overen")
else:
    print("SELHAL nebo CEKA — viz vystup vyse")
EOF
```

**Očekávaný výsledek:** Výstup obsahující `Success` nebo `attests existence as of` s číslem Bitcoin bloku.

**Alternativa — bez instalace:**
1. Nahrajte `anchor/anchor_receipt.ots` na **https://opentimestamps.org**
2. Na výzvu zadejte hodnotu `proof.json → anchor → payload_sha256`

> **Poznámka:** `payload_sha256` je SHA-256 kanonického JSON souboru `anchor/anchor_payload.json` (řazeno dle klíčů, bez mezer). Může se lišit od přímého hashe souboru kvůli formátování.

**Alternativa — ověření na Bitcoin block exploreru:**
- https://mempool.space/tx/`<proof.json → ots → bitcoin_tx>`
- https://blockstream.info/tx/`<proof.json → ots → bitcoin_tx>`

---

## Krok 4 — Ověření hash chainu

Potvrdí, že interní log událostí nebyl změněn.

```bash
python3 - <<'EOF'
import json

entries = [json.loads(l) for l in open("chain/proof_chain.jsonl") if l.strip()]
head = json.load(open("chain/chain_head.json"))
errors = 0

for i, e in enumerate(entries):
    if i > 0 and e["prev_hash"] != entries[i-1]["entry_hash"]:
        print(f"SELHAL — chain prerusen na seq {e['seq']}")
        errors += 1
    import hashlib
    material = f"{e['prev_hash']}|{e['event_type']}|{e['prob_id']}|{e['data_hash']}".encode()
    computed = hashlib.sha256(material).hexdigest()
    if computed != e["entry_hash"]:
        print(f"SELHAL — entry_hash nesouhlasi na seq {e['seq']}")
        errors += 1

if head["entry_hash"] != entries[-1]["entry_hash"]:
    print("SELHAL — hlava chainu neodpovida poslednimu zaznamu")
    errors += 1

if errors == 0:
    print(f"PROSEL — chain v poradku ({len(entries)} zaznamu, vsechny entry hashe overeny)")
    for e in entries:
        print(f"  seq {e['seq']}: {e['event_type']} v {e['created_at']}")
EOF
```

**Očekávaný výsledek:** `PROSEL — chain v poradku (N zaznamu, vsechny entry hashe overeny)`

---

## Co výsledky znamenají

| Krok | PROŠEL znamená |
|---|---|
| Krok 1 — Integrita souborů | Balíček nebyl od vygenerování změněn |
| Krok 2 — eIDAS razítko | Důkaz existoval v uvedený čas; podpis ověřen EU-akreditovanou autoritou |
| Krok 3 — Bitcoin anchor | Důkaz existoval nejpozději v Bitcoin bloku N; ověřitelné na veřejném blockchainu |
| Krok 4 — Hash chain | Interní log událostí je neporušený |
| Krok 5 — ISO 27037 artefakty | Síťové důkazy (TLS, DNS, HAR) potvrzují atribuci serveru |

**Pokud všech pět kroků projde: balíček je kryptograficky neporušený a forenzně ověřený dle ISO/IEC 27037.**

---

## Krok 5 — Ověření ISO/IEC 27037 forenzních artefaktů

Síťové důkazy vyžadované normou ISO/IEC 27037 § 6.4–6.5 a SWGDE 21-F-001 —
DNS, SSL/TLS certifikát, HTTP archiv a volitelně videozáznam zachycovací relace.

### 5a — Řetězec SSL/TLS certifikátů

Dokazuje, že zachycený obsah skutečně poskytl deklarovaný server (ne MITM,
ne unesené DNS, ne klonový server).

```bash
# Prohlédněte leaf cert, který server vystavil při zachycení
openssl x509 -in tls/leaf_cert.pem -noout -subject -issuer -dates -fingerprint -sha256

# Ověřte, že plný řetězec navazuje na známou root CA
openssl verify -CAfile /etc/ssl/certs/ca-certificates.crt tls/chain.pem
```

`subject` leaf certu by se měl shodovat se zachyceným hostnamem (nebo ho
pokrývat SAN/wildcard SAN). `verify OK` potvrzuje, že certifikát byl
v okamžiku zachycení podepsán uznávanou veřejnou CA.

Porovnejte SHA-256 fingerprint s `network/tls.json` →
`leaf_certificate.sha256_fingerprint`. Musí se shodovat.

### 5b — Snímek DNS resolution

Multi-resolver DNS důkaz (Cloudflare 1.1.1.1, Google 8.8.8.8, Quad9 9.9.9.9)
zachycený současně se stránkou. `network/dns.json → consensus` ukazuje
záznamy, na kterých se všechny tři resolvery shodly; `divergence` vypisuje
typy záznamů, kde se neshodly (forenzní red flag).

```bash
python3 -c "
import json
d = json.load(open('network/dns.json'))
print('Hostname:    ', d['hostname'])
print('Cas snimku:  ', d['captured_at_utc'])
for rtype, vals in d.get('consensus', {}).items():
    print(f'  {rtype:6s}', vals)
if d.get('divergence'):
    print('NESOULAD u:', d['divergence'])
"
```

### 5c — Záznam HTTP transakcí (HAR)

Soubor HAR (`network/capture.har`) je standardní W3C HTTP Archive obsahující
plnou sekvenci request/response zachycovací relace. Užitečný pro důkaz
**absence** neočekávaných přesměrování, JavaScript injekcí nebo modifikace
v tranzitu.

```bash
# Otevřete v libovolném HAR vieweru (Chrome DevTools, WebPageTest atd.)
# Nebo počítejte záznamy z CLI:
python3 -c "
import json
har = json.load(open('network/capture.har'))
entries = har.get('log',{}).get('entries',[])
print(f'{len(entries)} HTTP transakci behem zachyceni')
for e in entries[:5]:
    req = e['request']; resp = e['response']
    print(f'  {resp[\"status\"]:3d} {req[\"method\"]:4s} {req[\"url\"][:80]}')"
```

### 5d — Videozáznam (volitelný)

Pokud je `capture.webm` přítomen, ukazuje skutečnou zachycovací relaci
tak, jak ji viděl forenzní prohlížeč. Otevřete v moderním video přehrávači.

### 5e — RDAP / WHOIS snímek

`network/rdap.json` obsahuje registranta, registrátora, datum registrace
a expiraci viditelné v okamžiku zachycení. Užitečné, když je doména později
přesunuta, zabavena nebo přeregistrována.

---

*Vygenerováno systémem GetProofAnchor — https://getproofanchor.com*
*Nařízení eIDAS (EU) 910/2014, čl. 41(2) · ISO/IEC 27037:2012 · SWGDE 21-F-001*
